/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package perpustakaan;
import java.sql.*;
import java.util.Properties;
import java.io.FileOutputStream;
import java.io.IOException;
/**
 *
 * @author Fle1x
 */
public class UserAuth {
    
    public Statement st;
    public ResultSet rs;
    Connection cn = perpustakaan.KoneksiDatabase.BukaKoneksi();
    
    public class User {
    private String username;
    private String password;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Getters and setters
    }   
    public boolean validateLogin(String enteredUsername, String enteredPassword) {
        String dbUsername = ""; // Retrieve from database
        String dbPassword = "";
        String dbRole = "";// Retrieve from database
        String dbNama = "";
        String dbId = "";
        
        try {
            String query = "SELECT username, password,role,nama,id FROM user WHERE username = ? AND password = ?";
            PreparedStatement st = cn.prepareStatement(query);
            st.setString(1, enteredUsername);
            st.setString(2, enteredPassword);
            
            ResultSet rs = st.executeQuery();
            if(rs.next()) {
                dbUsername = rs.getString("username");
                dbPassword = rs.getString("password");
                dbRole = rs.getString("role");
                dbNama = rs.getString("nama");
                dbId = rs.getString("id");
            }
            
            rs.close();
            rs.close();
            cn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
              
        if(dbUsername.equals(enteredUsername) && dbPassword.equals(enteredPassword)){
            if (dbRole.equals("Admin")){
                Admin Admin = new Admin();
                Admin.setVisible(true);
            }else{
                Anggota Anggota = new Anggota();
                Anggota.setVisible(true);
            }
            Properties prop = new Properties();
            prop.setProperty("id", dbId);
            prop.setProperty("nama", dbNama);
            try (FileOutputStream out = new FileOutputStream("user.properties")) {
                prop.store(out, "User Login Data");
            } catch (IOException e) {
                e.printStackTrace();
            }
            
        }
        return dbUsername.equals(enteredUsername) && dbPassword.equals(enteredPassword);
    }
}