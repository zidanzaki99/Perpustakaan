/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package perpustakaan;

/**
 *
 * @author Fle1x
 */

import java.sql.*;
import javax.swing.JOptionPane;

public class KoneksiDatabase {
    Connection cn;
    public static Connection BukaKoneksi(){
        try {
            String url ="jdbc:mysql://localhost/db_perpus";
            String user="root";
            String pass="";
            Class.forName("com.mysql.jdbc.Driver");
            Connection cn = DriverManager.getConnection(url,user,pass);
            return cn;
        } catch (Exception e) {
            System.err.println("koneksi gagal" +e.getMessage());
        }
        return null;
    }
}
